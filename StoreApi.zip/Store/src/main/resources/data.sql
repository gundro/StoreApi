INSERT INTO store (user,favoriteFlag,name, address)
VALUES ('Ronith','Y','CCD','Amsterdam');
INSERT INTO store (user,favoriteFlag,name, address)
VALUES ('Narayana','Y','Flying Machine','Detroit');
INSERT INTO store (user,favoriteFlag,name, address)
VALUES ('Ronith','N','WROGN STORE','Los Angeles');
