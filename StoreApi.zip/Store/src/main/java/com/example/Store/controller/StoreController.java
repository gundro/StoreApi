/**
 * 
 */
package com.example.Store.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.example.Store.dao.StoreRepository;
import com.example.Store.vo.Store;


/**
 * @author ronith.gund
 *
 */
@RestController
@RequestMapping("/store")
public class StoreController {
	
	private static Logger log = LoggerFactory.getLogger(StoreController.class);
	
	@Autowired
	private StoreRepository storeRepo;
	
	
	
	 //@RequestMapping(value= "/all", method=RequestMethod.GET)
	
	@GetMapping(value = "/allStores")
	 public List<Store> getAllDtlsOfStore() {
		log.info("Entered getAllDtlsOfStore---->");
	  List<Store> storeDtls = storeRepo.findAll();
	  log.info("Successfully Called findAll method---> ");
	  log.info("List size : " + storeDtls.size() + "Values : " + storeDtls.get(0).getName());
	  for(int i=0 ; i<storeDtls.size(); i++)
	  {
		  log.info("id :" +  storeDtls.get(i).getId() + ", Name:" + 
				  storeDtls.get(i).getName() + ",Address :" + storeDtls.get(i).getAddress());
	  }
	  
	  return storeDtls;
	 }
	
	/**
	 * List of Stores Assigned to a user
	 */
	
	@GetMapping(value = "/{user}")
	public List<Store> getAllStoresUnderAUser(@PathVariable("user") String user) {
		log.info("Inside getAllStoresUnderAUser method");
		
		List<Store> storeDtls = null;
			storeDtls = storeRepo.getAllStoresUnderAUser(user);

		if (storeDtls.isEmpty()) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No data found in getAllStoresUnderAUser service");
		}
		
		return storeDtls;
	} 
	
	
	/**
	 * Mark a store as a favourite for a user
	 */
	@GetMapping(value = "favoriteFlag/{user}")
	public String updateFavoriteFlagforAStoreForAUser(@PathVariable("user") String user) {
		log.info("Inside updateFlagforAStoreForAUser method");
		
		int updRet = 0;
		updRet = storeRepo.updateFlagforAStoreForAUser(user);
		log.info("No of favorite flags got updated :" + updRet);

		if (updRet==0) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No stores available for the user to mark Favorite");
		}
		
		return "Stores marked as favourite for the user Successfully";
	} 
	
	/**
	 * Unmark a favourite store for a user
	 */
	@GetMapping(value = "unmarkFavoriteFlag/{user}")
	public String unmarkFavoriteFlagforAStoreForAUser(@PathVariable("user") String user) {
		log.info("Inside unmarkFavoriteFlagforAStoreForAUser method");
		
		int updRet = 0;
		updRet = storeRepo.unmarkFavoriteFlagforAStoreForAUser(user);
		log.info("No of favorite flags got updated to N:" + updRet);

		if (updRet==0) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "No stores available for the user to unmark Favorite");
		}
		
		return "Stores unmarked as favourite for the user Successfully";
	} 
	

}
