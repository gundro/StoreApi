/**
 * 
 */
package com.example.Store.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import org.springframework.jdbc.core.RowMapper;

import com.example.Store.mapper.StoreRowMapper;
import com.example.Store.vo.Store;

/**
 * @author ronith.gund
 *
 */

@Repository
public class StoreRepository {
	
	
	private final JdbcTemplate jdbcTemplate;
	
	
	@Autowired
	  public StoreRepository(JdbcTemplate jdbcTemplate) {
	    this.jdbcTemplate = jdbcTemplate;
	  }
	
	public List<Store> findAll() {
		  String query = "SELECT * from store";
		  RowMapper<Store> rowMapper = new StoreRowMapper();
		  List<Store> list = jdbcTemplate.query(query, rowMapper);
		  
		  return list;
		}

	public List<Store> getAllStoresUnderAUser(String user) {
		  String query = "SELECT * from store where user='" + user + "'";
		  RowMapper<Store> rowMapper = new StoreRowMapper();
		  List<Store> list = jdbcTemplate.query(query, rowMapper);
		  return list;
	}

	public int updateFlagforAStoreForAUser(String user) {
		String sqlQuery = "update store set " + 
                "favoriteFlag = 'Y' " +
                "where user = ? and favoriteFlag='N'";
        int updtStat = jdbcTemplate.update(sqlQuery
                , user);
        return updtStat;
	}

	public int unmarkFavoriteFlagforAStoreForAUser(String user) {
		String sqlQuery = "update store set " + 
                "favoriteFlag = 'N' " +
                "where user = ? and favoriteFlag='Y'";
        int updtStat = jdbcTemplate.update(sqlQuery
                , user);
        return updtStat;
	}
	
	
	
	
	
}
