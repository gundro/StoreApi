/**
 * 
 */
package com.example.Store.vo;

import java.io.Serializable;

/**
 * @author ronith.gund
 *
 */

public class Store implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3939434167856461699L;
	private Integer id;
	private String user;
	private String favoriteFlag;
	private String name;
	private String  address;
	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return the user
	 */
	public String getUser() {
		return user;
	}
	/**
	 * @param user the user to set
	 */
	public void setUser(String user) {
		this.user = user;
	}
	/**
	 * @return the favoriteFlag
	 */
	public String getFavoriteFlag() {
		return favoriteFlag;
	}
	/**
	 * @param favoriteFlag the favoriteFlag to set
	 */
	public void setFavoriteFlag(String favoriteFlag) {
		this.favoriteFlag = favoriteFlag;
	}
	
	
	
	
	
	

}
