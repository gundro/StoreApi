/**
 * 
 */
package com.example.Store.mapper;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.example.Store.vo.Store;

/**
 * @author ronith.gund
 *
 */
public class StoreRowMapper implements RowMapper<Store>  {
	
	@Override
	 public Store mapRow(ResultSet rs, int rowNum) throws SQLException {
	  Store store = new Store();
	  store.setId(rs.getInt("id"));
	  store.setUser(rs.getString("user"));
	  store.setFavoriteFlag(rs.getString("favoriteFlag"));
	  store.setName(rs.getString("name"));
	  store.setAddress(rs.getString("address"));
	  return store;
	 }

}
